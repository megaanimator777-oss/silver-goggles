package com.beatai.player

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sin

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val player = ExoPlayer.Builder(this).build()
        setContent { BeatAiApp(this, player) }
    }
    override fun onDestroy() {
        super.onDestroy()
    }
}

@Composable
fun BeatAiApp(context: Context, player: ExoPlayer) {
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var selected by remember { mutableIntStateOf(-1) }
    var playing by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    var visualMode by remember { mutableStateOf("Спектр") }
    var flashEnabled by remember { mutableStateOf(false) }
    var lyrics by remember { mutableStateOf("") }
    var currentMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(1L) }
    var amplitude by remember { mutableFloatStateOf(0.35f) }
    var permissionGranted by remember { mutableStateOf(false) }
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (granted) tracks = loadTracks(context)
    }

    LaunchedEffect(Unit) {
        permissionGranted = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        if (permissionGranted) tracks = loadTracks(context)
    }
    LaunchedEffect(player) {
        while (true) {
            currentMs = player.currentPosition.coerceAtLeast(0)
            durationMs = player.duration.takeIf { it > 0 } ?: 1L
            playing = player.isPlaying
            amplitude = if (playing) (0.25f + abs(sin(currentMs / 170.0)).toFloat() * 0.7f) else 0.12f
            delay(100)
        }
    }
    LaunchedEffect(flashEnabled, playing, amplitude) {
        if (flashEnabled && playing) {
            // Flash rhythm is intentionally rate-limited for device safety.
            delay(220)
            setTorch(context, amplitude > 0.73f)
        } else setTorch(context, false)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFB65CFF), secondary = Color(0xFF36D9FF),
        background = Color(0xFF080812), surface = Color(0xFF141426)
    )) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF080812)) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("BEAT", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 3.sp)
                        Text("AI MUSIC PLAYER", fontSize = 10.sp, color = Color(0xFF9C8BAF), letterSpacing = 3.sp)
                    }
                    Icon(Icons.Default.GraphicEq, null, tint = Color(0xFFB65CFF), modifier = Modifier.size(32.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Плеер", "Тексты", "Визуал").forEachIndexed { index, name ->
                        FilterChip(selected = tab == index, onClick = { tab = index }, label = { Text(name) })
                    }
                }
                Spacer(Modifier.height(12.dp))
                when (tab) {
                    0 -> {
                        if (selected in tracks.indices) {
                            NowPlayingCard(tracks[selected], playing, currentMs, durationMs, onSeek = { player.seekTo(it) },
                                onToggle = { if (player.isPlaying) player.pause() else player.play() },
                                onNext = { playTrack(selected + 1, tracks, player) },
                                onPrev = { playTrack((selected - 1).coerceAtLeast(0), tracks, player) })
                        } else EmptyPlayer()
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("МОЯ МУЗЫКА", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                            Text("${tracks.size} треков", color = Color.Gray, fontSize = 12.sp)
                        }
                        if (!permissionGranted) {
                            Button(onClick = { permissionLauncher.launch(permission) }, modifier = Modifier.fillMaxWidth()) {
                                Text("Разрешить доступ к музыке")
                            }
                        } else if (tracks.isEmpty()) {
                            Text("Музыка не найдена. Добавь аудиофайлы в память телефона.", color = Color.Gray, modifier = Modifier.padding(16.dp))
                        } else {
                            LazyColumn(contentPadding = PaddingValues(bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                itemsIndexed(tracks) { index, track ->
                                    TrackRow(track, selected == index) {
                                        selected = index
                                        lyrics = ""
                                        playTrack(index, tracks, player)
                                    }
                                }
                            }
                        }
                    }
                    1 -> LyricsScreen(lyrics, { lyrics = it }, tracks.getOrNull(selected)?.title ?: "Выбери песню")
                    else -> VisualizerScreen(visualMode, { visualMode = it }, amplitude, flashEnabled, { flashEnabled = it })
                }
                Spacer(Modifier.weight(1f))
                if (selected in tracks.indices && tab != 0) {
                    MiniPlayer(tracks[selected], playing, { if (playing) player.pause() else player.play() })
                }
                Text("BEAT AI • LOCAL FIRST", color = Color(0xFF665A78), fontSize = 9.sp, letterSpacing = 2.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 12.dp))
            }
        }
    }
}

fun loadTracks(context: Context): List<Track> {
    val list = mutableListOf<Track>()
    val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
    val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
    context.contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        while (cursor.moveToNext()) {
            val id = cursor.getLong(idCol)
            list += Track(id, cursor.getString(titleCol) ?: "Без названия",
                cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Неизвестный исполнитель",
                ContentUris.withAppendedId(collection, id), cursor.getLong(durationCol))
        }
    }
    return list
}

fun playTrack(index: Int, tracks: List<Track>, player: ExoPlayer) {
    if (index !in tracks.indices) return
    player.setMediaItem(MediaItem.fromUri(tracks[index].uri))
    player.prepare()
    player.play()
}

fun setTorch(context: Context, enabled: Boolean) {
    try {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        if (cameraId != null) manager.setTorchMode(cameraId, enabled)
    } catch (_: Exception) { }
}

@Composable
fun EmptyPlayer() {
    Box(Modifier.fillMaxWidth().height(190.dp).background(
        Brush.linearGradient(listOf(Color(0xFF24113D), Color(0xFF101B36))), RoundedCornerShape(24.dp)),
        contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.MusicNote, null, tint = Color(0xFFB65CFF), modifier = Modifier.size(46.dp))
            Text("ТВОЯ МУЗЫКА. ТВОИ ВОЛНЫ.", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Выбери трек из библиотеки", color = Color.LightGray, fontSize = 12.sp)
        }
    }
    Spacer(Modifier.height(16.dp))
}

@Composable
fun NowPlayingCard(track: Track, playing: Boolean, position: Long, duration: Long, onSeek: (Long) -> Unit,
                   onToggle: () -> Unit, onNext: () -> Unit, onPrev: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
        Box(Modifier.fillMaxWidth().height(180.dp).background(
            Brush.linearGradient(listOf(Color(0xFF3A145D), Color(0xFF122C55), Color(0xFF0A0A16))), RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                for (i in 0 until 36) {
                    val h = (18 + (sin(i * 0.7) * 30 + 35)).toFloat()
                    drawLine(Color(0xFFB65CFF).copy(alpha = 0.55f), Offset(size.width * i / 36f, size.height / 2 - h),
                        Offset(size.width * i / 36f, size.height / 2 + h), strokeWidth = 3f, cap = StrokeCap.Round)
                }
            }
            Icon(Icons.Default.Album, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(58.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(track.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(track.artist, color = Color(0xFFAA9CB9), fontSize = 13.sp)
        Slider(value = position.toFloat().coerceIn(0f, duration.toFloat()), onValueChange = { onSeek(it.toLong()) },
            valueRange = 0f..duration.toFloat(), colors = SliderDefaults.colors(thumbColor = Color(0xFFB65CFF), activeTrackColor = Color(0xFFB65CFF)))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPrev) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
            FilledIconButton(onClick = onToggle, modifier = Modifier.size(58.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF9B45E8))) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
        }
    }
}

@Composable
fun TrackRow(track: Track, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(if (selected) Color(0xFF26163B) else Color(0xFF12121F), RoundedCornerShape(14.dp))
        .clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Color(0xFF2D1B42), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.MusicNote, null, tint = Color(0xFFCB8AFF))
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(track.artist, color = Color.Gray, fontSize = 12.sp, maxLines = 1)
        }
        Icon(Icons.Default.PlayCircle, null, tint = Color(0xFFB65CFF))
    }
}

@Composable
fun LyricsScreen(lyrics: String, onLyrics: (String) -> Unit, trackName: String) {
    Column(Modifier.fillMaxSize()) {
        Text("LYRICS STUDIO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = 1.sp)
        Text(trackName, color = Color(0xFFB98CE4), fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Text("Текст песни", color = Color.LightGray, fontSize = 12.sp)
        OutlinedTextField(value = lyrics, onValueChange = onLyrics, modifier = Modifier.fillMaxWidth().weight(1f),
            placeholder = { Text("Вставь или напиши текст песни здесь…") },
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = Color(0xFFB65CFF), unfocusedBorderColor = Color(0xFF51435E)))
        Spacer(Modifier.height(8.dp))
        Text("Редактор текста уже доступен. Автоматическая построчная синхронизация и сохранение в библиотеку — следующий этап.",
            color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun VisualizerScreen(mode: String, onMode: (String) -> Unit, amplitude: Float, flash: Boolean, onFlash: (Boolean) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("VISUAL ENGINE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = 1.sp)
        Text("Выбери стиль визуализации", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(250.dp).background(
            Brush.linearGradient(listOf(Color(0xFF251044), Color(0xFF0C2540), Color(0xFF080812))), RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().padding(18.dp)) {
                val center = Offset(size.width / 2, size.height / 2)
                when (mode) {
                    "Кольцо" -> {
                        for (i in 0 until 100) {
                            val angle = i * Math.PI * 2 / 100
                            val inner = 52f
                            val outer = inner + 18f + amplitude * ((i * 17 % 31) + 12)
                            val x1 = center.x + kotlin.math.cos(angle).toFloat() * inner
                            val y1 = center.y + kotlin.math.sin(angle).toFloat() * inner
                            val x2 = center.x + kotlin.math.cos(angle).toFloat() * outer
                            val y2 = center.y + kotlin.math.sin(angle).toFloat() * outer
                            drawLine(Color(0xFFB65CFF), Offset(x1, y1), Offset(x2, y2), 3f, cap = StrokeCap.Round)
                        }
                    }
                    else -> {
                        for (i in 0 until 64) {
                            val h = 14f + amplitude * (15 + ((i * 23) % 85))
                            val x = size.width * i / 64f
                            drawLine(Color(0xFF36D9FF), Offset(x, center.y + h), Offset(x, center.y - h),
                                4f, cap = StrokeCap.Round)
                        }
                    }
                }
            }
            Text(mode.uppercase(), color = Color.White.copy(alpha = 0.65f), fontSize = 10.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp), letterSpacing = 3.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text("ПРЕСЕТЫ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Спектр", "Кольцо", "Волна").forEach { name ->
                FilterChip(selected = mode == name, onClick = { onMode(name) }, label = { Text(name) })
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().background(Color(0xFF171525), RoundedCornerShape(16.dp)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Вспышка под бит", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Использует фонарик телефона", color = Color.Gray, fontSize = 11.sp)
            }
            Switch(checked = flash, onCheckedChange = onFlash)
        }
        Text("Внимание: стробоскоп может быть опасен при фоточувствительности. Используй короткими сессиями и не направляй свет в глаза.",
            color = Color(0xFFFFB86B), fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun MiniPlayer(track: Track, playing: Boolean, onToggle: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF1A1425), RoundedCornerShape(16.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.MusicNote, null, tint = Color(0xFFB65CFF))
        Column(Modifier.weight(1f).padding(start = 8.dp)) {
            Text(track.title, color = Color.White, maxLines = 1, fontSize = 12.sp)
            Text(track.artist, color = Color.Gray, fontSize = 10.sp)
        }
        IconButton(onClick = onToggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White) }
    }
}
